class Developer{
    constructor(id, firstName, lastName, favoriteLanguage, yearStarted){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.favoriteLanguage = favoriteLanguage;
        this.yearStarted = yearStarted;
    }
}

export default Developer;