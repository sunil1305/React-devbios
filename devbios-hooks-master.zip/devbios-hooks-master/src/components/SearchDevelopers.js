import React, { useState } from 'react';
import clean from 'clean-tagged-string';

import DeveloperBio from './DeveloperBio';
import queryArgs from '../utils/gqlQueryBuilder';
import { searchDevelopers } from '../api/developerAPI';

function SearchDevelopers() {
    const [queryState, setQueryState] = useState({queryName:'devsByFirstName', queryValue:''});
    const [devSearchResult, setDevSearchResult] = useState();

    const handleChange = (event) => {
        setQueryState({
            ...queryState,
            [event.target.name]: event.target.value
        })
    }

    const submitForm = (event) => {
        event.preventDefault();

        let queryArgsFunction = queryArgs[queryState.queryName];
        let queryVars = queryArgsFunction(queryState.queryValue);

        const query = clean `{
            ${queryState.queryName}${queryVars}{
                id,
                firstName,
                lastName,
                favoriteLanguage,
                yearStarted
            }
        }`

        searchDevelopers(query)
        .then(res=>setDevSearchResult(res.data[queryState.queryName]));
    }

    return (
        <div>
            <div className="container">
                <h1>Search Developer Bios</h1>
                <div className="row">
                    <div className="col-md-6">
                        <form onSubmit={submitForm} id="searchForm" >
                            <div className="form-group">
                                <label htmlFor="searchField">Choose Field</label>
                                <select name="queryName" className="form-control" onChange={handleChange}>
                                    <option value="devsByFirstName">First Name</option>
                                    <option value="devsByLastName">Last Name</option>
                                    <option value="devsByFavLang">Favorite Language</option>
                                    <option value="devsByYearStarted">Year Started</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <input type="text" name="queryValue" className="form-control" onChange={handleChange}/>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                {
                    devSearchResult
                    ?
                        devSearchResult.map(dev=><DeveloperBio developer={dev} key={dev.id}/>)
                    :
                        <div></div>
                }
            </div>
        </div>
    )
}

export default SearchDevelopers;
