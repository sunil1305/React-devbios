import React, { useContext, useState, useEffect } from 'react';
import { useParams, withRouter } from 'react-router-dom';
import AppContext from '../contexts';
import DeveloperForm from './DeveloperForm';
import { putDeveloper } from '../api/developerAPI';

function EditDeveloper(props) {
    const { id } = useParams();
    const { developers } = useContext(AppContext);
    const [ developer, setDeveloper ] = useState();

    useEffect(() => {
        developers 
        ?
            setDeveloper(developers.find(dev=>dev.id===id))
        :
            props.history.push("/bios");
    }, [id, developers, setDeveloper]);

    const submitForm = (dev) => {
        putDeveloper(dev)
        .then(props.history.push("/bios"));
    }

    return (
        developer
        ?
            <DeveloperForm title="Edit" developer={developer} submitForm={submitForm} />
        :
            <div></div>
    )
}

export default withRouter(EditDeveloper);
