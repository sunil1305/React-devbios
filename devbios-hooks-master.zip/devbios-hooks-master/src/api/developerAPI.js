export const getDevelopers = () => {
    return fetch("https://tech-services-1000201953.uc.r.appspot.com/developers")
        .then(response => response.json());
}

export const postDeveloper = (developer) => {
    return (
        fetch("https://tech-services-1000201953.uc.r.appspot.com/developer",
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(developer)
            }
        )
    );
}

export const putDeveloper = (developer) => {
    return (
        fetch("https://tech-services-1000201953.uc.r.appspot.com/developer",
            {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(developer)
            }
        )
    );
}

export const searchDevelopers = (query) => {
    return (
        fetch(`https://dev-bios-graphql-dot-tech-services-1000201953.uc.r.appspot.com/q?query=${encodeURIComponent(query)}`)
        .then(res=>res.json())
    )
}
