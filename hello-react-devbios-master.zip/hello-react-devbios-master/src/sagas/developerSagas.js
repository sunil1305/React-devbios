import { call, put, takeLatest, fork } from 'redux-saga/effects';
import { getDevelopers, postDeveloper } from '../api/developerAPI';
import devActions, { Types } from '../reducers/devReducers';

//workers
function* getDevBios(){
    try {
        const developers = yield call(getDevelopers);
        yield put(devActions.getAllBiosSuccessActionCreator(developers));
    } catch (error) {
        console.log('Error occurred fetching Developers: '+error);
    }
}

function* addDevBio({developer}){
    try {
        const result = yield call(postDeveloper,developer);
    } catch (error) {
        console.log("Error occurred posting Developer: "+error);
    }
}

//watchers
function* watchGetAllBiosRequest(){
    yield takeLatest(Types.GET_ALL_BIOS_REQUEST, getDevBios);
}

function* watchAddBioPost(){
    yield takeLatest(Types.ADD_BIO, addDevBio);
}

const developerSagas = [
    fork(watchGetAllBiosRequest),
    fork(watchAddBioPost)
]

export default developerSagas;