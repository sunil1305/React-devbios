import React, { Component } from 'react';
import { connect } from 'react-redux';

import DeveloperBio from './DeveloperBio';
import devActions from '../reducers/devReducers';

class DisplayBios extends Component{
    constructor(props){
        super(props);
        props.addDevsToStore();
    }

    render(){
        return (
            this.props.developers
            ?
                this.props.developers.map((dev, index)=><DeveloperBio developer={dev} key={index} />)
            :
                <div></div>
        );
    }
}

export default connect(({developers})=>({
    developers: developers//match state to prop
}),{
    addDevsToStore: devActions.getAllBiosRequestActionCreator
})(DisplayBios);
